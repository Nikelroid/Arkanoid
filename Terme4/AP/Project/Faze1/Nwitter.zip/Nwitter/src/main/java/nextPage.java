public class nextPage {

    public nextPage() {
        new nextPage(1);
    }
    public nextPage(int i) {
        for (int j = 0; j < i; j++) {
            System.out.println();
        }

    }
}
